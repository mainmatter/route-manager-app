declare module '@glimmer/compiler/lib/passes/1-normalization/keywords/utils/if-unless' {
    import type * as ASTv2 from "@glimmer/syntax/lib/v2/api";
    import type { KeywordDelegate } from "@glimmer/compiler/lib/passes/1-normalization/keywords/impl";
    import * as mir from "@glimmer/compiler/lib/passes/2-encoding/mir";
    export function ifUnlessInlineKeyword(type: string): KeywordDelegate<ASTv2.CallExpression | ASTv2.AppendContent, {
        condition: ASTv2.ExpressionNode;
        truthy: ASTv2.ExpressionNode;
        falsy: ASTv2.ExpressionNode | null;
    }, mir.IfInline>;
}