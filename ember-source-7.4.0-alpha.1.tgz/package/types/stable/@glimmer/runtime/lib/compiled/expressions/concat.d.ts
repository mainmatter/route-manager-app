declare module '@glimmer/runtime/lib/compiled/expressions/concat' {
    import type { Reference } from "@glimmer/reference/lib/reference";
    export function createConcatRef(partsRefs: Reference[]): Reference<string | null>;
}