declare module '@glimmer/runtime/lib/dom/fragment-region' {
    import type { Bounds, Nullable, SimpleDocumentFragment, SimpleElement, SimpleNode } from "@glimmer/interfaces";
    /**
     * A DocumentFragment cannot stay in the DOM. Inserting one moves its children
     * out and leaves the fragment empty, so the fragment is not an address that
     * later renders can target.
     *
     * A region is that address. It is a pair of comment markers around the place
     * where the fragment's children went, so `{{#in-element fragment}}` can render
     * into the same place after `{{fragment}}` already emptied the fragment.
     *
     * The fragment stays the owner of the content. When the region goes away, the
     * content moves back into the fragment instead of being thrown away, so a
     * `{{fragment}}` that renders again shows the same nodes with their state
     * intact.
     */
    export class FragmentRegion implements Bounds {
        private fragment;
        private parent;
        private open;
        private close;
        constructor(fragment: SimpleDocumentFragment, parent: SimpleElement | SimpleDocumentFragment, open: SimpleNode, close: SimpleNode);
        parentNode(): SimpleElement | SimpleDocumentFragment;
        firstNode(): SimpleNode;
        lastNode(): SimpleNode;
        /**
         * New content goes before the close marker. This keeps the content inside the
         * region, and keeps sibling regions in template order.
         */
        insertionPoint(): SimpleNode;
        isLive(): boolean;
        /**
         * Removes the content of the region and keeps the markers, which is the
         * fragment equivalent of removing an element's children.
         */
        clearContent(): void;
        /**
         * Moves the content of the region back into the fragment it came from.
         */
        private returnContent;
        private eachContentNode;
    }
    /**
     * Serialized region markers. The client uses empty comments, but a serialized
     * document has to name them so that rehydration can find the region again.
     */
    export const FRAGMENT_REGION_OPEN = "%+f%";
    export const FRAGMENT_REGION_CLOSE = "%-f%";
    /**
     * Creates a region for a fragment and records it as the fragment's current one.
     */
    export function makeFragmentRegion(
     fragment: SimpleDocumentFragment,
     parent: SimpleElement | SimpleDocumentFragment,
     open: SimpleNode,
     close: SimpleNode
    ): FragmentRegion;
    /**
     * Returns the region that a fragment currently renders through, or null if the
     * fragment was never rendered or its region was since removed from the DOM.
     */
    export function fragmentRegionFor(node: SimpleElement | SimpleDocumentFragment): Nullable<FragmentRegion>;
}