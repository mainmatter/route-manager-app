declare module '@glimmer/runtime/lib/bounds' {
    import type { Bounds, Cursor, Maybe, Nullable, SimpleDocumentFragment, SimpleElement, SimpleNode } from "@glimmer/interfaces";
    export class CursorImpl implements Cursor {
        element: SimpleElement | SimpleDocumentFragment;
        nextSibling: Nullable<SimpleNode>;
        constructor(element: SimpleElement | SimpleDocumentFragment, nextSibling: Nullable<SimpleNode>);
    }
    export type DestroyableBounds = Bounds;
    export class ConcreteBounds implements Bounds {
        private parent;
        private first;
        private last;
        constructor(parent: SimpleElement | SimpleDocumentFragment, first: SimpleNode, last: SimpleNode);
        parentNode(): SimpleElement | SimpleDocumentFragment;
        firstNode(): SimpleNode;
        lastNode(): SimpleNode;
    }
    /**
     * `SimpleNode#parentNode` is typed as any node, but the DOM only ever reports an
     * element, a fragment, or a document as a parent, and Glimmer never appends
     * directly to a document. The parent is therefore always an insertion point.
     */
    export function parentOf(node: Maybe<SimpleNode>): Nullable<SimpleElement | SimpleDocumentFragment>;
    /**
     * The parent to mutate through: normally the stored parentNode(), but when the
     * bounds were rendered into a DocumentFragment that was later appended to the
     * DOM, the nodes' live parentNode is the container while the stored parent is
     * the (now-empty) fragment.
     */
    export function liveParent(bounds: Bounds): SimpleElement | SimpleDocumentFragment;
    export function move(bounds: Bounds, reference: Nullable<SimpleNode>): Nullable<SimpleNode>;
    export function clear(bounds: Bounds): Nullable<SimpleNode>;
}