declare module '@ember/-internals/glimmer/lib/helpers/element' {
    /**
      @module @ember/helper
    */
    const _default: object;
    export default _default;
}