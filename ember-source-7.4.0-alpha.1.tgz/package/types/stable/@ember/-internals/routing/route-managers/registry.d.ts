declare module '@ember/-internals/routing/route-managers/registry' {
    /**
      Registry that associates a `RouteManagerFactory` with a route definition
      (typically a `Route` class).
    */
    import type { RouteManagerFactory } from "@ember/-internals/routing/route-managers/api";
    /**
      Associates a `RouteManagerFactory` with `definition`. The router calls the
      factory the first time it needs a manager for any route whose class extends
      (directly or via prototype chain) `definition`.

      ```ts
      import { setRouteManager } from '@ember/routing';

      class MyRouteManager { ... }

      setRouteManager((owner) => new MyRouteManager(owner), MyRoute);
      ```

      @param factory Factory invoked once per owner with that owner as its only
        argument. Must return an object whose `capabilities` field was produced by
        `routeCapabilities`.
      @param definition The route class or object the manager applies to.
     */
    export function setRouteManager<Def extends object>(factory: RouteManagerFactory, definition: Def): Def;
    /**
      Returns the `RouteManagerFactory` registered for `definition`, walking the
      prototype chain. Returns `undefined` if no manager is registered.

      Note that this only returns the factory, the router is responsible for
      invoking it (typically once per owner) and caching the resulting manager
      instance.

      Not to be confused with `getRouteManagement` (router_js): this registry is
      keyed by the route **class** and answers "which kind of manager handles
      routes of this class?", while `getRouteManagement` is keyed by a route
      **instance** and returns the live manager instance + bucket driving it.
      `EmberRouter.getRoute` connects the two — it resolves the factory here,
      instantiates the manager and bucket, then records the per-instance result
      via `associateRouteManagement`.
     */
    export function getRouteManager(definition: object): RouteManagerFactory | undefined;
}