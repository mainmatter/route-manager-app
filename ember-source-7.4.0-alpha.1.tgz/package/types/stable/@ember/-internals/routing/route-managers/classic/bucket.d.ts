declare module '@ember/-internals/routing/route-managers/classic/bucket' {
    import type Controller from "@ember/controller";
    import type { InternalOwner } from "@ember/-internals/owner";
    import type Route from "@ember/routing/route";
    import type { scheduleOnce } from "@ember/runloop";
    export class ClassicRouteBucket {
        route: Route;
        get controller(): Controller | undefined;
        get owner(): InternalOwner;
        loadingSubstateTimer: ReturnType<typeof scheduleOnce> | null;
        constructor(route: Route);
    }
}