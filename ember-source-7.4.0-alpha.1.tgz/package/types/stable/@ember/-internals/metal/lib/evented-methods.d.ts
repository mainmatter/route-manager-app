declare module '@ember/-internals/metal/lib/evented-methods' {
    export function eventedOn(
      obj: object,
      name: string,
      target: object | Function | null,
      method?: Function | PropertyKey
    ): void;
    export function eventedOne(
      obj: object,
      name: string,
      target: object | Function | null,
      method?: Function | PropertyKey
    ): void;
    export function eventedTrigger(obj: object, name: string, args: any[]): void;
    export function eventedOff(
      obj: object,
      name: string,
      target: object | Function | null,
      method?: string | Function
    ): void;
    export function eventedHas(obj: object, name: string): boolean;
}