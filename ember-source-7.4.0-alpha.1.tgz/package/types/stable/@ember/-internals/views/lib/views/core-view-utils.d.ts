declare module '@ember/-internals/views/lib/views/core-view-utils' {
    import type CoreView from "@ember/-internals/views/lib/views/core_view";
    export function sendCoreViewEvent(view: CoreView, name: string, args?: any[]): any;
    export function hasCoreViewListener(view: CoreView, name: string): boolean;
}