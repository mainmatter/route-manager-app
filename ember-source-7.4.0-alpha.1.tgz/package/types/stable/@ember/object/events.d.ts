declare module '@ember/object/events' {
    import { sendEvent as originalSendEvent } from "@ember/-internals/metal/lib/events";
    export function addListener<Target>(
      obj: object,
      eventName: string,
      target: Target,
      method: PropertyKey | ((this: Target, ...args: any[]) => void),
      once?: boolean,
      sync?: boolean
    ): void;
    export function addListener(
      obj: object,
      eventName: string,
      method: PropertyKey | ((...args: any[]) => void)
    ): void;
    export function removeListener<Target>(
      obj: object,
      eventName: string,
      target: Target,
      method: PropertyKey | ((this: Target, ...args: any[]) => void)
    ): void;
    export function removeListener(
      obj: object,
      eventName: string,
      method: PropertyKey | ((...args: any[]) => void)
    ): void;
    export const sendEvent: (...args: Parameters<typeof originalSendEvent>) => boolean;
}