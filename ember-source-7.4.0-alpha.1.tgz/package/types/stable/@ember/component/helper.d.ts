declare module '@ember/component/helper' {
    export { default, helper, type FunctionBasedHelper, type FunctionBasedHelperInstance, } from "@ember/-internals/glimmer/lib/helper";
}