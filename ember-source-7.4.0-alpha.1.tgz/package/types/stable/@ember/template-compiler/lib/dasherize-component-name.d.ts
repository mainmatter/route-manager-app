declare module '@ember/template-compiler/lib/dasherize-component-name' {
    import Cache from "@ember/-internals/utils/lib/cache";
    const _default: Cache<string, string>;
    export default _default;
}