declare module 'router_js/lib/transition-intent/named-transition-intent' {
    import type { Dict } from "router_js/lib/core";
    import type InternalRouteInfo from "router_js/lib/route-info";
    import { UnresolvedRouteInfoByObject, UnresolvedRouteInfoByParam } from "router_js/lib/route-info";
    import type { ParsedHandler } from "router_js/lib/router";
    import type Router from "router_js/lib/router";
    import { TransitionIntent } from "router_js/lib/transition-intent";
    import TransitionState from "router_js/lib/transition-state";
    export default class NamedTransitionIntent extends TransitionIntent {
        name: string;
        pivotName?: string;
        contexts: unknown[];
        queryParams: Dict<unknown>;
        preTransitionState?: TransitionState;
        constructor(router: Router, name: string, pivotName: string | undefined, contexts?: unknown[], queryParams?: Dict<unknown>, data?: object);
        applyToState(oldState: TransitionState, isIntermediate: boolean): TransitionState;
        applyToHandlers(oldState: TransitionState, parsedHandlers: ParsedHandler[], targetRouteName: string, isIntermediate: boolean, checkingIfActive: boolean): TransitionState;
        invalidateChildren(handlerInfos: InternalRouteInfo[], invalidateIndex: number): void;
        getHandlerInfoForDynamicSegment(name: string, names: string[], objects: unknown[], oldHandlerInfo: InternalRouteInfo, _targetRouteName: string, i: number): UnresolvedRouteInfoByObject;
        createParamHandlerInfo(name: string, names: string[], objects: unknown[], oldHandlerInfo: InternalRouteInfo): UnresolvedRouteInfoByParam;
    }
}