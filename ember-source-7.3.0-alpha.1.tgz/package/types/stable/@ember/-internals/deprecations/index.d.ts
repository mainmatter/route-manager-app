declare module '@ember/-internals/deprecations' {
    import type { DeprecationOptions } from "@ember/debug/lib/deprecate";
    export function emberVersionGte(until: string, emberVersion?: number): boolean;
    export function isRemoved(options: DeprecationOptions): boolean;
    interface DeprecationObject {
        options: DeprecationOptions;
        test: boolean;
        isEnabled: boolean;
        isRemoved: boolean;
    }
    export const DEPRECATIONS: {
        DEPRECATE_IMPORT_EMBER(importName: string): {
            options: DeprecationOptions;
            test: boolean;
            isEnabled: boolean;
            isRemoved: boolean;
        };
        DEPRECATE_IMPORT_INJECT: {
            options: DeprecationOptions;
            test: boolean;
            isEnabled: boolean;
            isRemoved: boolean;
        };
        DEPRECATE_COMPARABLE_MIXIN: {
            options: DeprecationOptions;
            test: boolean;
            isEnabled: boolean;
            isRemoved: boolean;
        };
    };
    export function deprecateUntil(message: string, deprecation: DeprecationObject): void;
    export {};
}