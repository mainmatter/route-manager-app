declare module '@ember/-internals/routing/route-managers/classic/outlet-template' {
    const _default: import("@glimmer/interfaces").TemplateFactory;
    export default _default;
}