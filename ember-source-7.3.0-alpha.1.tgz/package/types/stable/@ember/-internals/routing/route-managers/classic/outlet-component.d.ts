declare module '@ember/-internals/routing/route-managers/classic/outlet-component' {
    class OutletComponent {
    }
    /** Module-stable per RFC-1169. */
    export const CLASSIC_OUTLET: OutletComponent;
    export {};
}