declare module '@ember/-internals/routing/route-managers/outlet-state' {
    import type { InternalOwner } from "@ember/-internals/owner";
    export interface RenderState {
        /**
         * This is usually inherited from the parent (all the way up to the app
         * instance). However, engines uses this to swap out the owner when crossing
         * a mount point.
         */
        owner: InternalOwner;
        /**
         * The name of the route/template
         */
        name: string;
        /**
         * The route's invokable, passed to the wrapper as `@Component`.
         */
        invokable: object | undefined;
    }
    export interface OutletManager {
        /** Module-stable per RFC-1169; the framework curries this level's state onto it. */
        getRouteWrapper(): object;
    }
    /**
     * What the outlet walk descends from.
     */
    export interface OutletParent {
        /**
         * Represents what, if any, should be rendered into the next {{outlet}} found
         * at this level.
         *
         * This used to be a dictionary of children outlets, including the {{outlet}}
         * "main" outlet any {{outlet "named"}} named outlets. Since named outlets
         * are not a thing anymore, this can now just be a single`child`.
         */
        outlets: {
            main: OutletState | undefined;
        };
    }
    /** Narrower than the route info that satisfies it: `enterPromise` is not a manager's business. */
    export interface ContextSource {
        readonly context?: unknown;
        readonly enterPromise?: Promise<unknown>;
    }
    /** One rendered instance of a route. */
    export class OutletState implements OutletParent {
        readonly render: RenderState;
        readonly manager: OutletManager;
        readonly bucket: object;
        readonly invokable: object | undefined;
        /** Passed to the wrapper as `@context`. */
        context: unknown;
        readonly outlets: {
            main: OutletState | undefined;
        };
        constructor(render: RenderState, manager: OutletManager, bucket: object, invokable: object | undefined, source: ContextSource);
    }
}