declare module '@ember/-internals/routing/route-managers/classic/bucket' {
    import type Controller from "@ember/controller";
    import type Route from "@ember/routing/route";
    import type { scheduleOnce } from "@ember/runloop";
    export class ClassicRouteBucket {
        route: Route;
        invokable: object | undefined;
        get controller(): Controller | undefined;
        loadingSubstateTimer: ReturnType<typeof scheduleOnce> | null;
        constructor(route: Route);
    }
}