declare module '@ember/-internals/routing/route-managers/classic/bucket' {
    import type Controller from "@ember/controller";
    import type { InternalOwner } from "@ember/-internals/owner";
    import type Route from "@ember/routing/route";
    import type { scheduleOnce } from "@ember/runloop";
    export class ClassicRenderState {
        readonly bucket: ClassicRouteBucket;
        invokable: object | undefined;
        constructor(bucket: ClassicRouteBucket);
        get owner(): InternalOwner;
        get name(): string;
    }
    export class ClassicRouteBucket {
        route: Route;
        invokable: object | undefined;
        get controller(): Controller | undefined;
        loadingSubstateTimer: ReturnType<typeof scheduleOnce> | null;
        readonly render: ClassicRenderState;
        constructor(route: Route);
    }
}