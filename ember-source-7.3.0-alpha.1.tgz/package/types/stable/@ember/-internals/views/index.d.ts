declare module '@ember/-internals/views' {
    export { addChildView, isSimpleClick, getViewBounds, getViewClientRects, getViewBoundingClientRect, getRootViews, getChildViews, getViewId, getElementView, getViewElement, setElementView, setViewElement, clearElementView, clearViewElement, constructStyleDeprecationMessage, } from "@ember/-internals/views/lib/system/utils";
    export { default as EventDispatcher } from "@ember/-internals/views/lib/system/event_dispatcher";
    export { default as CoreView } from "@ember/-internals/views/lib/views/core_view";
    export { default as ActionSupport } from "@ember/-internals/views/lib/mixins/action_support";
    export { MUTABLE_CELL } from "@ember/-internals/views/lib/compat/attrs";
    export { default as ViewStates } from "@ember/-internals/views/lib/views/states";
}