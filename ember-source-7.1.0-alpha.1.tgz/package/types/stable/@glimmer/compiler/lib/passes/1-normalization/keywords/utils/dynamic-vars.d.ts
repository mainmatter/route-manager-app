declare module '@glimmer/compiler/lib/passes/1-normalization/keywords/utils/dynamic-vars' {
    import type { ASTv2 } from "@glimmer/syntax";
    import type { GenericKeywordNode, KeywordDelegate } from "@glimmer/compiler/lib/passes/1-normalization/keywords/impl";
    import * as mir from "@glimmer/compiler/lib/passes/2-encoding/mir";
    export const getDynamicVarKeyword: KeywordDelegate<GenericKeywordNode, ASTv2.ExpressionNode, mir.GetDynamicVar>;
}