declare module '@glimmer/interfaces/lib/runtime/owner' {
    export type Owner = object;
}