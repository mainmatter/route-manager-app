declare module '@glimmer/runtime/lib/compiled/opcodes/-debug-strip' {
    import type { Checker } from "@glimmer/debug";
    import type { CapabilityMask, CapturedArguments, CompilableBlock, CompilableProgram, ComponentDefinition, ComponentInstance, ElementOperations, Helper, InternalComponentManager, Invocation, Nullable, Scope, ScopeBlock } from "@glimmer/interfaces";
    import type { OpaqueIterator, Reference } from "@glimmer/reference";
    import type { Tag } from "@glimmer/validator";
    import { VMArgumentsImpl } from "@glimmer/runtime/lib/vm/arguments";
    import { ComponentElementOperations } from "@glimmer/runtime/lib/compiled/opcodes/component";
    export const CheckTag: Checker<Tag>;
    export const CheckOperations: Checker<Nullable<ComponentElementOperations>>;
    export const CheckReference: Checker<Reference>;
    export const CheckIterator: Checker<OpaqueIterator>;
    export const CheckArguments: Checker<VMArgumentsImpl>;
    export const CheckHelper: Checker<Helper>;
    export class UndefinedReferenceChecker implements Checker<Reference> {
        type: Reference;
        validate(value: unknown): value is Reference;
        expected(): string;
    }
    export const CheckUndefinedReference: UndefinedReferenceChecker;
    export const CheckCapturedArguments: Checker<CapturedArguments>;
    export const CheckScope: Checker<Scope>;
    export const CheckComponentManager: Checker<InternalComponentManager>;
    export const CheckCapabilities: Checker<CapabilityMask>;
    export const CheckComponentInstance: Checker<ComponentInstance>;
    export const CheckCurriedComponentDefinition: Checker<object | Function>;
    export const CheckInvocation: Checker<Invocation>;
    export const CheckElementOperations: Checker<ElementOperations>;
    export const CheckFinishedComponentInstance: Checker<ComponentInstance>;
    export const CheckCompilableBlock: Checker<CompilableBlock>;
    export const CheckCompilableProgram: Checker<CompilableProgram>;
    export const CheckScopeBlock: Checker<ScopeBlock>;
    export const CheckComponentDefinition: Checker<ComponentDefinition>;
}