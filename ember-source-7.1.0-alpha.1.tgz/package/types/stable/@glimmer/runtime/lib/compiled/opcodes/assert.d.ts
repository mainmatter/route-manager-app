declare module '@glimmer/runtime/lib/compiled/opcodes/assert' {
    export function stackAssert(name: string, top: unknown): string;
}