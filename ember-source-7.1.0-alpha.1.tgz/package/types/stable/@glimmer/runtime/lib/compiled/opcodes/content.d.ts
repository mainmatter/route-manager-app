declare module '@glimmer/runtime/lib/compiled/opcodes/content' {
    export {};
}