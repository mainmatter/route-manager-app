declare module '@glimmer/runtime/lib/helpers/internal-helper' {
    import type { Helper, HelperDefinitionState } from "@glimmer/interfaces";
    export function internalHelper(helper: Helper): HelperDefinitionState;
}