declare module '@ember/test' {
    import type * as EmberTesting from "ember-testing";
    export let registerWaiter: (typeof EmberTesting.Test)["registerWaiter"];
    export let unregisterWaiter: (typeof EmberTesting.Test)["unregisterWaiter"];
    export let _impl: typeof EmberTesting | undefined;
    export function registerTestImplementation(impl: typeof EmberTesting): void;
}