declare module '@ember/template-compiler/lib/public-api' {
    export { template } from "@ember/template-compiler/lib/template";
    export type { EmberPrecompileOptions } from "@ember/template-compiler/lib/types";
}