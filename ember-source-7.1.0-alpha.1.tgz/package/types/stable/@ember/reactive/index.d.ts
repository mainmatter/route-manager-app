declare module '@ember/reactive' {
    /**
     * The `@ember/reactive` package contains common reactive utilities
     * for tracking values and creating reactive data structures.
     *
     * @module @ember/reactive
     * @public
     */
    const _default: {};
    export default _default;
}