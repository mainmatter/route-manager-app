declare module '@ember/-internals/routing/route-managers/classic-route-manager' {
    import type { Destroyable } from "@glimmer/interfaces";
    import type Owner from "@ember/owner";
    import type Route from "@ember/routing/route";
    import type { RouteManager, RouteCapabilities, NavigationState, NavigationActions, AsyncNavigationState, CreateRouteArgs, NavigationStateWithTransition } from "@ember/-internals/routing/route-managers/route-manager";
    import type { RouteStateBucket } from "@ember/-internals/routing/route-managers/utils";
    import { Promise } from "rsvp";
    export class ClassicRouteBucket implements RouteStateBucket {
        route: Route;
        args: CreateRouteArgs;
        context: unknown;
        controller: unknown;
        invokable: object | undefined;
        enterPromise: Promise<unknown> | undefined;
        loadingSubstateTimer: unknown;
        constructor(route: Route, args: CreateRouteArgs);
    }
    /**
     * Extra args provided to manager methods when classicInterop is enabled.
     * These give the ClassicRouteManager access to router_js internals needed
     * to replicate the classic hook behaviour.
     */
    export interface ClassicInteropArgs {
        transition: any;
        routeInfo: any;
    }
    /**
     * The ClassicRouteManager wraps the classic Route lifecycle so that all
     * routes flow through the RouteManager interface. Every method delegates
     * to the Route instance stored in the bucket.
     *
     * Capabilities: classicInterop = true
     */
    export class ClassicRouteManager implements RouteManager<ClassicRouteBucket> {
        #private;
        capabilities: RouteCapabilities;
        constructor(owner: Owner);
        createRoute(RouteClass: typeof Route, args: CreateRouteArgs): ClassicRouteBucket;
        getDestroyable(bucket: ClassicRouteBucket): Destroyable | null;
        private _runBeforeModel;
        private _getModel;
        private _runAfterModel;
        private _isTransition;
        willEnter(bucket: ClassicRouteBucket, args: NavigationState & NavigationActions & NavigationStateWithTransition): void;
        private _enterLoadingSubstate;
        private _findRouteSubstateName;
        private _findRouteStateName;
        private _routeHasBeenDefined;
        enter(bucket: ClassicRouteBucket, args: NavigationState & NavigationActions & AsyncNavigationState & NavigationStateWithTransition): Promise<unknown>;
        didEnter(bucket: ClassicRouteBucket, _args: NavigationState): void;
        willExit(bucket: ClassicRouteBucket, _args: NavigationState & NavigationActions): void;
        exit(bucket: ClassicRouteBucket, _args: NavigationState): void;
        didExit(_bucket: ClassicRouteBucket, _args: NavigationState): void;
        getInvokable(bucket: ClassicRouteBucket): Promise<object | undefined>;
        _buildInvokable(bucket: ClassicRouteBucket): object;
    }
}