declare module '@ember/-internals/routing' {
    export { controllerFor, generateController, generateControllerFactory, DSL as RouterDSL, } from "@ember/routing/-internals";
    export { setRouteManager, getRouteManager } from "@ember/-internals/routing/route-managers/utils";
    export type { RouteStateBucket } from "@ember/-internals/routing/route-managers/utils";
    export { ClassicRouteManager } from "@ember/-internals/routing/route-managers/classic-route-manager";
    export type { ClassicRouteBucket } from "@ember/-internals/routing/route-managers/classic-route-manager";
    export type { RouteManager, RouteCapabilities, NavigationState, NavigationActions, AsyncNavigationState, CreateRouteArgs, } from "@ember/-internals/routing/route-managers/route-manager";
    export { routeCapabilities } from "@ember/-internals/routing/route-managers/route-manager";
}